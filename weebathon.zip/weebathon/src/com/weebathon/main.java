package com.weebathon;

import java.sql.ResultSet;
import java.sql.SQLException;

public class main {
	public static void main(String [] args) {
		System.out.println("Starting the Server Thread");
		ServerThread st = new ServerThread();
		st.start();
	}
}
