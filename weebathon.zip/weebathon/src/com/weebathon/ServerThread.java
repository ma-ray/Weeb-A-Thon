package com.weebathon;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ServerThread extends Thread{
	
	public void run() {
		String time="";

			Mysql mysql;
			try {
				mysql = new Mysql("root", "", "localhost", "3306","animeweebs");
			
			while(true) {
			//Check for update
			ResultSet rs = mysql.getResult("SELECT * FROM `reactdatainput`"); 
			rs.next();
			String datelastupdate = rs.getString("datelastupdated");
			
			if(time.equals(datelastupdate)) {
				updateOutput();
				time = datelastupdate;
			}
			
			System.out.println("Checking Complete");
			//Change the output
			
			
			Thread.sleep(50);
			
			} 
			
			}catch (SQLException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public void updateOutput() {
		
		
	}
}
