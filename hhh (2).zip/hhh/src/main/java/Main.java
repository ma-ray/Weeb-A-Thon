
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import static java.util.Collections.list;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;




public class Main {
    static final int THRESHOLD = 40;
    static String[] liked;
    static String[] disliked;
    
    private static List<Anime> get_relevant_animes(List<Anime> all_animes) {
        List<Anime> relevants = new ArrayList<Anime>();
        for (ListIterator<Anime> iter = all_animes.listIterator(); iter.hasNext(); ) {
            Anime anime = iter.next();
        if (anime.getAkscore() < THRESHOLD) {
            iter.remove();
        }
    }
        
        return relevants;
    }
    
    private static int get_ak_score(Anime all_animes, User user) {
        //Formula for 1 <= Ak score <= 100, 
        int ak_score =  Math.min(100, Math.max(0, Math.max(10 * user.getUserLiked(), 100) +
            Math.max(-10 * user.getUserDisliked(),  -100)));
        
        return ak_score;
    }
    
    private static List<Anime> sort_animes(List<Anime> animess) {
    //animess.arrayList.sort(Comparator.comparing(Anime::getAkscore)); almost works
     return null;
    }
    
    static List<Anime> read_animes() throws IOException {
        List<Anime> all_animes = new ArrayList<Anime>();
        Anime current_anime;
        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\chris\\Documents\\NetBeansProjects\\hhh\\src\\main\\java\\test.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                current_anime = new Anime();
                 current_anime.setName(line);
                //line = br.readLine();
                //current_anime.setName(line);
                line = br.readLine();
                current_anime.setDescription(line);
                line = br.readLine();
                current_anime.setGenres(line);
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                line = br.readLine();
                if (!line.equals("N/A")) {
                    current_anime.setScore(Double.valueOf(line));
                }
                line = br.readLine();
                if (current_anime != null){all_animes.add(current_anime);}
                }
            }
        return all_animes;
  }
public static void main(String[] args) throws IOException {

    //String name, BufferedImage object, double score, String genres[], String description,String type,int AkScore
    //Anime anime = new Anime("", null, 0, new String[0], "", "", 0);
    
    List<Anime> all_animes = read_animes();
    
  /*  for(Anime a : all_animes) {
        a.printa(a);
    }*/
    List<Anime> relevant_anime = get_relevant_animes(all_animes); 
    
    relevant_anime = sort_animes(relevant_anime);
    
 //   Gui panel = new Gui(relevant_anime);
  //Creates gui object with the list of relevant anime
}
}