
import java.awt.image.BufferedImage;

// Object for the anime!
public class Anime {
    private String name, type, description;
    private BufferedImage object;
    private double score;
    private String genres[];
    private int AkScore;
//String name, BufferedImage object, double score, String genres[], String description,String type,int AkScore
    public Anime() {
        //this.name = name;
       // this.object = object;
       // this.score = score;
       // this.description = description;
       // this.type = type; 
       // this.AkScore = AkScore;
       // this.genres = genres;

    }

    public String getName() {
        return name;
    }

    public int getAkscore() {    
        return AkScore;
    }

    public void setAkscore(int score) {    
        this.AkScore = score;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BufferedImage getObject() {
        return object;
    }

    public void setObject(BufferedImage object) {
        this.object = object;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public String[] getGenres() {
        return genres;
    }

    public void setGenres(String genres) {
        this.genres = genres.split(",", 100); 
    } 
    
    public void printa(Anime a){
        System.out.println(a.getName() + ": ");
        System.out.println(a.getDescription());
        System.out.println("Genres: " + a.getGenres());
        System.out.println("MAL Rating: " + a.getScore());
        System.out.println();
    }
    
}