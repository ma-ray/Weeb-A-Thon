import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Mysql {
	
	Connection conn;
	
	public Mysql(String username, String password, String ip, String port, String database) throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:mysql://"+ip+":"+port+"/"+database,username,password);
	}
	
	public void execute(String sql) {
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ResultSet getResult(String sql) {
		try {
                        
			Statement stmt = conn.createStatement();
			return stmt.executeQuery("SELECT * FROM `reactdatatable`");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ResultSet rs = null;
		return rs;
	}
}
