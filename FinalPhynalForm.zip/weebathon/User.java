//package swing;


import java.awt.image.BufferedImage;

// Object for the anime!
public class User {
    private String name;
    private String likedGenres[];
    private String dislikedGenres[];

    public User() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String[] getLikedGenres() {
        return likedGenres;
    }

    public void setLikedGenres(String[] likedGenres) {
        this.likedGenres = likedGenres;
    }

    public String[] getDislikedGenres() {
        return dislikedGenres;
    }


    public void setDislikedGenres(String[] dislikedGenres) {
        this.dislikedGenres = dislikedGenres;
    }

    public int getNumDisliked(String[] animeGenres, String[] personalDislikes) {
        int numdislikes = 0;
        for (int i = 0; i < Math.min(animeGenres.length,personalDislikes.length); i++) {
            if (animeGenres.length <= personalDislikes.length) {
                for (int j = 0; j < personalDislikes.length; j++) {
                     if (animeGenres[i].equals(personalDislikes[j])) { numdislikes++;}
                }
            } else {
                for (int j = 0; j < animeGenres.length; j++) {
                    if (animeGenres[j].equals(personalDislikes[i])) { numdislikes++;}
            }
        }
    }
        return numdislikes;
    }
    
    public int getNumLiked(String[] animeGenres, String[] personalLikes) {
        int numLike = 0;
        for (int i = 0; i < Math.min(animeGenres.length, personalLikes.length); i++) {
            if (animeGenres.length <= personalLikes.length) {
                for (int j = 0; j < personalLikes.length; j++) {
                     if (animeGenres[i].equals(personalLikes[j])) { numLike++;}
                }
            } else {
                for (int j = 0; j < animeGenres.length; j++) {
                     if (animeGenres[j].equals(personalLikes[i])) { numLike++;}
                }
            }
        }
        return numLike;
    }
}